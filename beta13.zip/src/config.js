export default {
    SECRET : 'secret_key_word'
}